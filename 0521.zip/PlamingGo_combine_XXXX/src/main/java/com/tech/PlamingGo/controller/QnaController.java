package com.tech.PlamingGo.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.tech.PlamingGo.dao.QnaDao;
import com.tech.PlamingGo.dto.QnaDto;



@Controller
public class QnaController {
	
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("/customer")
	public String customer() {
		System.out.println("customer");
		return "/customer";
	}
	@RequestMapping("/c_list")
	public String c_list(Model model,
			HttpServletRequest request ) {
	System.out.println("c_list()");
	QnaDao qdao = sqlSession.getMapper(QnaDao.class);
	
	model.addAttribute("c_list",qdao.c_list());
		
		return "/c_list";
	}
	@RequestMapping("/c_writeview")
	public String c_writeview() {
	System.out.println("c_writeview()");
		return "/c_writeview";
	}
	
	@RequestMapping("/c_write")
	public String c_write(Model model,
		HttpServletRequest request, HttpServletResponse response) throws Exception {
	System.out.println("c_write()");
	
	String path = this.getClass().getResource("").getPath();
	path=path.substring(1,path.indexOf(".metadata"))+"/PlamingGo_sewon0520/src/main/webapp/resources/upload";
	System.out.println("path : "+path);
	
	MultipartRequest req =
			new MultipartRequest(request, path,
					10*1024*1024,"UTF-8",
					new DefaultFileRenamePolicy());
	
	String qna_writer=req.getParameter("qna_writer");
	String qna_title=req.getParameter("qna_title");
	String qna_content=req.getParameter("qna_content");
	String fName=req.getFilesystemName("file");//**
	if(fName==null)
		fName="";
	
	QnaDao qdao = sqlSession.getMapper(QnaDao.class);
	qdao.c_write(qna_writer, qna_title, qna_content, fName);
	
	return "redirect:c_list";
	
	}
	@RequestMapping("/download")
	public String download(HttpServletRequest request,
			HttpServletResponse response,
			Model model) throws Exception {
		System.out.println("pass download()");
		String path=request.getParameter("p");
		String fname=request.getParameter("f");
		String bid=request.getParameter("bid");
		
		response.setHeader("Content-Disposition", 
				"Attachment;filename="
		+URLEncoder.encode(fname,"utf-8"));//첨부처리, 한글처리
		//다운
		String attachPath="resources\\upload\\";
		String realPath=request.getSession()
				.getServletContext()
				.getRealPath(attachPath)+"\\"+fname;
		
		FileInputStream fin=new FileInputStream(realPath);
		ServletOutputStream sout=response.getOutputStream();
		
		byte[] buf=new byte[1024];
		int size=0;
		
		while ((size=fin.read(buf, 0, 1024))!=-1) {
			sout.write(buf, 0, size);
		}
		fin.close();
		sout.close();
		
		return "c_contentview?bid="+bid;
		
	}
	@RequestMapping("/c_contentview")
	public String c_contentview(HttpServletRequest request,
			Model model) {
		System.out.println("pass contentview()");
//		model.addAttribute("request", request);
//		commandInp=new BContentViewService();
//		commandInp.execute(model);
		String qna_num=request.getParameter("qna_num");
		QnaDao dao=sqlSession.getMapper(QnaDao.class);
		dao.upHit(qna_num);//카운트증가
		QnaDto dto=dao.contentView(qna_num);//상세뷰
		model.addAttribute("c_contentview", dto);
		
		return "c_contentview";
	}
	@RequestMapping(value = "/c_modify",method = RequestMethod.POST)
	public String modify(HttpServletRequest request,
			Model model) {
		System.out.println("pass c_modify()");
		//수정구현
//		model.addAttribute("request", request);
//		commandInp=new BModifyService();
//		commandInp.execute(model);
		
		String qna_num=request.getParameter("qna_num");
		String qna_writer=request.getParameter("qna_writer");
		String qna_title=request.getParameter("qna_title");
		String qna_content=request.getParameter("qna_content");
		QnaDao qdao =sqlSession.getMapper(QnaDao.class);
		qdao.c_modify(qna_num, qna_writer, qna_title, qna_content);
		
		return "redirect:c_list";
	}
	
}
