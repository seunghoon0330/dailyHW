package com.tech.PlamingGo.controller;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DramaController_admin {

	@Autowired
	private SqlSession sqlsession;
	
	
	// 드라마 등록
	@RequestMapping("/drama/write")
	public String drama_write() {
		
		return "/drama/write";
	}
}
