package com.tech.PlamingGo.dao;

import java.util.ArrayList;

import com.tech.PlamingGo.dto.MovieDto;


public interface MovieDao {
	
	public ArrayList<MovieDto> getmovielist();
	public MovieDto moviedetail(String movie_code);
	
	
	
}
