package com.tech.PlamingGo.dao;

import com.tech.PlamingGo.dto.JoinDto;

public interface JoinDao {

	
	public JoinDto reg(
			String user_id,
			String user_pw,
			String user_email,
			String user_name,
			String user_birth,
			int user_gender,
			String user_phone
			);


}


