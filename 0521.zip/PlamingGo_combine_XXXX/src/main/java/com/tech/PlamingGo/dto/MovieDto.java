package com.tech.PlamingGo.dto;

public class MovieDto {
	private int movie_code;
	private String movie_title;
	private String movie_img;
	private String movie_age;
	private String movie_time;
	private String movie_summary;
	private String movie_director;
	private String movie_actor;
	private String movie_genre;
	private String movie_nation;
	private String movie_date;
	private double movie_rating;
	
	
	public int getMovie_code() {
		return movie_code;
	}

	public void setMovie_code(int movie_code) {
		this.movie_code = movie_code;
	}

	public String getMovie_title() {
		return movie_title;
	}

	public void setMovie_title(String movie_title) {
		this.movie_title = movie_title;
	}

	public String getMovie_img() {
		return movie_img;
	}

	public void setMovie_img(String movie_img) {
		this.movie_img = movie_img;
	}

	public String getMovie_age() {
		return movie_age;
	}

	public void setMovie_age(String movie_age) {
		this.movie_age = movie_age;
	}

	public String getMovie_time() {
		return movie_time;
	}

	public void setMovie_time(String movie_time) {
		this.movie_time = movie_time;
	}

	public String getMovie_summary() {
		return movie_summary;
	}

	public void setMovie_summary(String movie_summary) {
		this.movie_summary = movie_summary;
	}

	public String getMovie_director() {
		return movie_director;
	}

	public void setMovie_director(String movie_director) {
		this.movie_director = movie_director;
	}

	public String getMovie_actor() {
		return movie_actor;
	}

	public void setMovie_actor(String movie_actor) {
		this.movie_actor = movie_actor;
	}

	public String getMovie_genre() {
		return movie_genre;
	}

	public void setMovie_genre(String movie_genre) {
		this.movie_genre = movie_genre;
	}

	public String getMovie_nation() {
		return movie_nation;
	}

	public void setMovie_nation(String movie_nation) {
		this.movie_nation = movie_nation;
	}

	public String getMovie_date() {
		return movie_date;
	}

	public void setMovie_date(String movie_date) {
		this.movie_date = movie_date;
	}

	public double getMovie_rating() {
		return movie_rating;
	}

	public void setMovie_rating(double movie_rating) {
		this.movie_rating = movie_rating;
	}

	// 기본생성자
	public MovieDto() {
		// TODO Auto-generated constructor stub
	}
	


	public MovieDto(int movie_code, String movie_title, String movie_img,
			String movie_age, String movie_time, String movie_summary, String movie_director, String movie_actor,
			String movie_genre, String movie_nation, String movie_date, double movie_rating) {
		super();
		this.movie_code = movie_code;
		this.movie_title = movie_title;
		this.movie_img = movie_img;
		this.movie_age = movie_age;
		this.movie_time = movie_time;
		this.movie_summary = movie_summary;
		this.movie_director = movie_director;
		this.movie_actor = movie_actor;
		this.movie_genre = movie_genre;
		this.movie_nation = movie_nation;
		this.movie_date = movie_date;
		this.movie_rating = movie_rating;
	}
	
	

}
