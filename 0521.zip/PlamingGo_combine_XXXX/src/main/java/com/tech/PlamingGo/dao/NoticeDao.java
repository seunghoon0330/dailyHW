package com.tech.PlamingGo.dao;

import java.util.ArrayList;

import com.tech.PlamingGo.dto.NoticeDto;
import com.tech.PlamingGo.dto.QnaDto;

public interface NoticeDao {
	public ArrayList<NoticeDto> notice();
	
	public void n_write(String notice_writer, String notice_title,
			String notice_content, String fName);
	public NoticeDto contentView(String notice_num);
	public void upHit(String strid);
	public void n_modify(String notice_num, String notice_writer, 
			String notice_title, String notice_content);

	
}
