package com.tech.PlamingGo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.tech.PlamingGo.dao.NoticeDao;
import com.tech.PlamingGo.dao.QnaDao;

@Controller
public class NoticeController {
	
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("/notice")
	public String notice() {
	System.out.println("notice");

	return "/notice";
}
	
//	@RequestMapping("/notice")
//		public String notice(Model model, HttpServletRequest request) {
//		System.out.println("notice");
//		NoticeDao ndao = sqlSession.getMapper(NoticeDao.class);
//		model.addAttribute("notice",ndao.notice());
//		
//		return "/notice";
//	}
	
	
	@RequestMapping("/n_writeview")
	public String n_writeview() {
	System.out.println("n_writeview pass");
		return "/n_writeview";
	}
	
	@RequestMapping("/n_write")
	public String n_write(Model model,
			HttpServletRequest request, HttpServletResponse respone) throws Exception {
		System.out.println("n_write pass");
		
//		
		
		String path=this.getClass().getResource("").getPath();
		MultipartRequest req=
				new MultipartRequest(request, path);
		
		String notice_writer=req.getParameter("notice_writer");
		String notice_title=req.getParameter("notice_title");
		String notice_content=req.getParameter("notice_content");
		String fName=req.getFilesystemName("file");
	
		if (fName==null) 
			fName="";
			
		NoticeDao ndao = sqlSession.getMapper(NoticeDao.class);
		ndao.n_write(notice_writer, notice_title, notice_content, fName);
		
		return "redirect:notice";
		}
		@RequestMapping(value = "/n_modify",method = RequestMethod.POST)
		public String modify(HttpServletRequest request,
				Model model) {
			System.out.println("pass n_modify()");
			//수정구현
//			model.addAttribute("request", request);
//			commandInp=new BModifyService();
//			commandInp.execute(model);
			
			String notice_num=request.getParameter("notice_num");
			String notice_writer=request.getParameter("notice_writer");
			String notice_title=request.getParameter("notice_title");
			String notice_content=request.getParameter("notice_content");
			NoticeDao ndao =sqlSession.getMapper(NoticeDao.class);
			ndao.n_modify(notice_num, notice_writer, notice_title, notice_content);
			
			return "redirect:notice";
		
		}
	
	}		



