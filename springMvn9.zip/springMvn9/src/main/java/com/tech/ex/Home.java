package com.tech.ex;

public class Home {
	private String paName;
	private String mamName;
	private String sisName;
	private String broName;
	
	public Home(String paName, String mamName) {
		this.paName = paName;
		this.mamName = mamName;
	}
	
	public String getPaName() {
		return paName;
	}
	public void setPaName(String paName) {
		this.paName = paName;
	}
	public String getMamName() {
		return mamName;
	}
	public void setMamName(String mamName) {
		this.mamName = mamName;
	}
	public String getSisName() {
		return sisName;
	}
	public void setSisName(String sisName) {
		this.sisName = sisName;
	}
	public String getBroName() {
		return broName;
	}
	public void setBroName(String broName) {
		this.broName = broName;
	}
	
	

}
