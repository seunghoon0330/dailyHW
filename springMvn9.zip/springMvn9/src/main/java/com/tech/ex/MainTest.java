package com.tech.ex;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainTest {
	public static void main(String[] args) {
		String classpath1="classpath:appCtx1.xml";
		String classpath2="classpath:appCtx2.xml";
		AbstractApplicationContext ctx=
				new GenericXmlApplicationContext(classpath1,classpath2);
		Member member1=ctx.getBean("member1",Member.class);
		System.out.println(member1.getName());
		System.out.println(member1.getHobbys());
		
		MemberInfo memberInfo=ctx.getBean("memberInfo1",MemberInfo.class);
		Member member2=memberInfo.getMember();
		
		//member1== member2������?
		if (member1.equals(member2)) {
			System.out.println("member1==member2");
		}
		
		Member member3=ctx.getBean("member3",Member.class);
		System.out.println(member3.getName());
		if (member1.equals(member3)) {
			System.out.println("member1==member3");
		}else {
			System.out.println("member1!=member3");
		}
		
		
	}

}
