package com.tech.aPrj2;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ComController {
	
	@RequestMapping("/com/computerview")
	public String computerview(Model model) {
		model.addAttribute("cpu","인텔");
		model.addAttribute("mboard","게이밍보드");
		model.addAttribute("monitor","삼성모니터");
		
		return "/com/computerview";
	}

}
