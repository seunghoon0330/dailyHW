package com.tech.aPrj2;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyInfoController {
	//이름, 주소를 전달하는 메소드를 생성
	//myinfo.jsp
	
	@RequestMapping("/addr/myinfo")//호출 경로 지정 addr폴터에 myinfo jsp파일 호출
	public String myinfo(Model model) {
		model.addAttribute("name","hong");
		model.addAttribute("addr", "강동");
		return "/addr/myinfo";
	}
}
