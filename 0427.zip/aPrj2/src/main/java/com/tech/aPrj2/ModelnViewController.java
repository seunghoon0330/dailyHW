package com.tech.aPrj2;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ModelnViewController {
	//modelnview controller
	//model 매개변수가 아닌 객체를 생성
	
	@RequestMapping("/model/modelview")
	public ModelAndView modelnview() {
		ModelAndView mv=new ModelAndView();//mv라는ModelAndView 객체생성
		mv.addObject("cpu", "인텔");//mv에 cpu키 생성
		mv.addObject("mboard","게이밍보드");
		mv.addObject("monitor","삼성모니터");
		mv.setViewName("/model/modelview");//뷰딴 경로설정
		
		return mv; //=ModelAndView
	}
	
	
}
