package com.tech.aPrj5;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MemberController {

	@RequestMapping("/member/memberForm")
	public String memberForm() {

		
		return "/member/memberForm";
	}
	
	@RequestMapping("/member/memberView")
	public String memberView(HttpServletRequest request, Model model) {
		System.out.println("Form신호");
		String name=request.getParameter("name");
		String id=request.getParameter("id");
		String pw=request.getParameter("pw");
		
		model.addAttribute("name", name);
		model.addAttribute("id", id);
		model.addAttribute("pw", pw);
		
		System.out.println("name : "+name);
		System.out.println("id : "+id);
		System.out.println("pw : "+pw);
		
		return "/member/memberView";
	}
}
