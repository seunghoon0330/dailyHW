package com.tech.aPrjetc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


		//패키지가 달라진다면 src-main-webapp-WEB-INF-spring-appServlet-servlet-context.xml에서
		//<context:component-scan base-package="com.tech.패키지이름" /> 루트를 설정해줘야함
@Controller
public class OtherController {
	
	@RequestMapping("/other/otherview")
	public String otherview() {
		
		return "/other/otherview";
	}
}
