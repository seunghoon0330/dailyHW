package com.tech.aPrj3;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/board")
public class BoardController {
	
	@RequestMapping("/boardview")//폴더를 잡아줬기 떄문에 하위 폴더만
	public String boardview() {
		
		
		return "/board/boardview";
	}
}
