package com.tech.aPrj;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CarController {

	@RequestMapping("/carForm/carForm")
	public String carForm() {
		
		return "/carForm/carForm";
	}
	@RequestMapping("carView/carView")
	public String CarView(HttpServletRequest request,Model model) {
		System.out.println("Form신호");
		
		String cName=request.getParameter("cName");
		String cColor=request.getParameter("cColor");
		String cKind=request.getParameter("cKind");
		
		model.addAttribute("cName", cName);
		model.addAttribute("cColor", cColor);
		model.addAttribute("cKind", cKind);
		
		System.out.println("car name : "+cName);
		System.out.println("car color : "+cColor);
		System.out.println("car kind : "+cKind);
		
		return "/carView/carView";
		
	}
}
