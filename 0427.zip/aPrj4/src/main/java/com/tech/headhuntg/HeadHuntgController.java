package com.tech.headhuntg;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HeadHuntgController {
	
	@RequestMapping("/headhuntg/headhuntgview")
		public String HeadHuntg(Model model) {
		model.addAttribute("headhuntg", "머갈통");
		
		return "/headhuntg/headhuntgview";
	}
	
}
