package com.tech.jobinfo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class JobController {
	
	@RequestMapping("/jobinfo/jobinfoview")
		public String HeadHuntg(Model model) {
		model.addAttribute("jobinfo", "jobinfoview");
		
		return "/jobinfo/jobinfoview";
	}
	
}
