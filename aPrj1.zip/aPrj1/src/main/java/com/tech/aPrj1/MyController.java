package com.tech.aPrj1;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
	@RequestMapping("mrh")
	public String mrh() {
		return "mrh";
	}

}
