package com.tech.spring_tx_board.service;

import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.tech.spring_tx_board.dao.BoardDao;
import com.tech.spring_tx_board.dto.BoardDto;

public class BContentViewService implements BServiceInp{

	@Override
	public void execute(Model model) {
		System.out.println("BContentViewService execute");
		Map<String, Object> map=model.asMap();
		HttpServletRequest request=
				(HttpServletRequest) map.get("request");
		String bid=request.getParameter("bid");
		BoardDao dao=new BoardDao();
		BoardDto dto=dao.contentView(bid);
		
		model.addAttribute("content_view", dto);
	}

}
