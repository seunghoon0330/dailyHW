package com.tech.spring_tx_board.service;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.tech.spring_tx_board.dao.BoardDao;
import com.tech.spring_tx_board.dto.BoardDto;

public class BReplyService implements BServiceInp{

	@Override
	public void execute(Model model) {
		System.out.println("BReplyService execute");
		Map<String, Object>map=model.asMap();
		HttpServletRequest request=
				(HttpServletRequest) map.get("request");
		
		String bid=request.getParameter("bid");
		String bname=request.getParameter("bname");
		String btitle=request.getParameter("btitle");
		String bcontent=request.getParameter("bcontent");
		String bgroup=request.getParameter("bgroup");
		String bstep=request.getParameter("bstep");
		String bindent=request.getParameter("bindent");
		
		BoardDao dao=new BoardDao();
		dao.reply(bid,bname,btitle,bcontent,
				bgroup,bstep,bindent);
		
	}

}
