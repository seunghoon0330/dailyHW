package com.tech.spring_tx_board.service;

import org.springframework.ui.Model;

public interface BServiceInp {
	public void execute(Model model);

}
