package com.tech.spring_tx_board.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tech.spring_tx_board.service.BContentViewService;
import com.tech.spring_tx_board.service.BDeleteService;
import com.tech.spring_tx_board.service.BListService;
import com.tech.spring_tx_board.service.BModifyService;
import com.tech.spring_tx_board.service.BReplyService;
import com.tech.spring_tx_board.service.BReplyViewService;
import com.tech.spring_tx_board.service.BServiceInp;
import com.tech.spring_tx_board.service.BWriteService;

@Controller
public class BController {
	BServiceInp commandInp;

	@RequestMapping("/list")
	public String list(Model model) {
		System.out.println("pass list()");
		//db에서 데이터추출 list에 전송
		commandInp=new BListService();
		commandInp.execute(model);
		
		return "list";
	}
	
	@RequestMapping("/write_view")
	public String write_view() {
		System.out.println("pass write_view()");
		return "write_view";
	}
	@RequestMapping("/write")
	public String write(HttpServletRequest request,
			Model model) {
		System.out.println("pass write()");
		
		model.addAttribute("request", request);
		
		commandInp=new BWriteService();
		commandInp.execute(model);

		return "redirect:list";
	}
	
	@RequestMapping("/content_view")
	public String content_view(HttpServletRequest request,
			Model model) {
		System.out.println("pass content_view()");
		model.addAttribute("request", request);
		commandInp=new BContentViewService();
		commandInp.execute(model);
		
		return "content_view";
	}
	@RequestMapping(value = "/modify",method = RequestMethod.POST)
	public String modify(HttpServletRequest request,
			Model model) {
		System.out.println("pass modify()");
		//수정구현
		model.addAttribute("request", request);
		commandInp=new BModifyService();
		commandInp.execute(model);
		
		return "redirect:list";
	}
	
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,
			Model model) {
		System.out.println("pass delete()");
		//delete 구현
		model.addAttribute("request", request);
		commandInp=new BDeleteService();
		commandInp.execute(model);
		
		return "redirect:list";
	}
	
	@RequestMapping(value = "/reply_view")
	public String reply_view(HttpServletRequest request,
			Model model) {
		System.out.println("pass reply_veiw()");
//		String bid=request.getParameter("bid");
		model.addAttribute("request", request);
		commandInp=new BReplyViewService();
		commandInp.execute(model);
		
		return "reply_view";
	}
	
	@RequestMapping(value = "/reply")
	public String reply(HttpServletRequest request,
			Model model) {
		System.out.println("pass reply()");
		model.addAttribute("request", request);
		commandInp=new BReplyService();
		commandInp.execute(model);
		
		return "redirect:list";
	}
	
	
	
}
