package com.tech.spring_tx_board.dao;

import java.util.ArrayList;

import com.tech.spring_tx_board.dto.BoardDto;

public interface IDao {

}
