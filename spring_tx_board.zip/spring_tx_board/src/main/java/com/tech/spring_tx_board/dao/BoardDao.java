package com.tech.spring_tx_board.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.tech.spring_tx_board.dto.BoardDto;

public class BoardDao {
	DataSource dataSource;
	public BoardDao() {
		System.out.println("BoardDao() 호출");
		//db 접속객체 얻기
		try {
			Context context=new InitialContext();
			dataSource=
					(DataSource) context.lookup("java:comp/env/jdbc/orcl");
		} catch (NamingException e) {
			e.printStackTrace();
		}	
	}
	public ArrayList<BoardDto> list() {
		System.out.println("dao list()");
		//db에서 데이터 추출 list에 담아 리턴
		ArrayList<BoardDto> dtos=new ArrayList<BoardDto>();
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			con=dataSource.getConnection();
			String sql="select bid,bname,btitle,bcontent,"
					+"bdate,bhit,bgroup," 
					+"bstep,bindent from mvc_board "
					+"order by bgroup desc,bstep asc";
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while (rs.next()) {
				int bid=rs.getInt("bid");
				String bname=rs.getString("bname");
				String btitle=rs.getString("btitle");
				String bcontent=rs.getString("bcontent");
				Timestamp bdate=rs.getTimestamp("bdate");
				int bhit=rs.getInt("bhit");
				int bgroup=rs.getInt("bgroup");
				int bstep=rs.getInt("bstep");
				int bindent=rs.getInt("bindent");
				//db에서 데이터 가져온 상태
				BoardDto dto=new BoardDto(bid, bname, btitle, bcontent, bdate, bhit, bgroup, bstep, bindent);
				dtos.add(dto);//레코드하나 리스트에 추가
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (rs!=null) {	rs.close();}
				if (pstmt!=null) {	pstmt.close();}
				if (con!=null) {	con.close();}
			} catch (Exception e2) {
			}
		}
		return dtos;	
	}
	
	public void write(String bname,
			String btitle, String bcontent) {
		System.out.println("dao write()");
		// db 접속, 실제 insert
		Connection con=null;
		PreparedStatement pstmt=null;
		
		try {
			con=dataSource.getConnection();
			String sql="insert into mvc_board(bid,bname,btitle,"
					+"bcontent, bhit,bgroup,bstep,bindent)"
					+" values(mvc_board_seq.nextval,"
					+"?,?,?,0,"
					+ "mvc_board_seq.currval,0,0)";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, bname);
			pstmt.setString(2, btitle);
			pstmt.setString(3, bcontent);
			int rn=pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt!=null) {	pstmt.close();}
				if (con!=null) {	con.close();}
			} catch (Exception e2) {
			}
		}
	}
	
	public BoardDto contentView(String seqid) {
		System.out.println("dao contentView()");
		BoardDto dto=null;
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			con=dataSource.getConnection();
			String sql="select * from mvc_board where bid=?";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, seqid);
			
			rs=pstmt.executeQuery();
			if (rs.next()) {
				int bid=rs.getInt("bid");
				String bname=rs.getString("bname");
				String btitle=rs.getString("btitle");
				String bcontent=rs.getString("bcontent");
				Timestamp bdate=rs.getTimestamp("bdate");
				
				int bhit=rs.getInt("bhit");
				int bgroup=rs.getInt("bgroup");
				int bstep=rs.getInt("bstep");
				int bindent=rs.getInt("bindent");
				
				dto=new BoardDto(bid, bname, btitle,
						bcontent, bdate, bhit,
						bgroup, bstep, bindent);	
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (rs!=null) {	rs.close();}
				if (pstmt!=null) {	pstmt.close();}
				if (con!=null) {	con.close();}
			} catch (Exception e2) {
			}
		} 
		return dto;
	}

}
