package com.tech.spring_tx_board.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tech.spring_tx_board.service.BContentViewService;
import com.tech.spring_tx_board.service.BListService;
import com.tech.spring_tx_board.service.BServiceInp;
import com.tech.spring_tx_board.service.BWriteService;

@Controller
public class BController {
	BServiceInp commandInp;

	@RequestMapping("/list")
	public String list(Model model) {
		System.out.println("pass list()");
		//db에서 데이터추출 list에 전송
		commandInp=new BListService();
		commandInp.execute(model);
		
		return "list";
	}
	
	@RequestMapping("/write_view")
	public String write_view() {
		System.out.println("pass write_view()");
		return "write_view";
	}
	@RequestMapping("/write")
	public String write(HttpServletRequest request,
			Model model) {
		System.out.println("pass write()");
		
		model.addAttribute("request", request);
		
		commandInp=new BWriteService();
		commandInp.execute(model);

		return "redirect:list";
	}
	
	@RequestMapping("/content_view")
	public String content_view(HttpServletRequest request,
			Model model) {
		System.out.println("pass content_view()");
		model.addAttribute("request", request);
		commandInp=new BContentViewService();
		commandInp.execute(model);
		
		return "content_view";
	}
	
	
	
	
}
