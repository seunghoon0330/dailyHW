package com.tech.ex;

import org.springframework.context.support.GenericXmlApplicationContext;

public class MainAop {
	public static void main(String[] args) {
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("classpath:appCtx.xml");
		Student student=ctx.getBean("student",Student.class);
		student.getStudentInfo();
		System.out.println("=================================================================");
		
		Worker worker=ctx.getBean("worker",Worker.class);
		worker.getWorkerInfo();
	}
}
