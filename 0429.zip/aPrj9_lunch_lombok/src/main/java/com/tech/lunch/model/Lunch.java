package com.tech.lunch.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter //Setter와 Getter를 자동으로 생성해줌 Outline 으로 확인가능 게터엔 세터와 똑같지만 가독성과 편리성이 좋음
//@Data = data확인인듯 ;; 
public class Lunch {
	private String fname;
	private String fprice;
	private String fkind;
	private String floc;
	
}
